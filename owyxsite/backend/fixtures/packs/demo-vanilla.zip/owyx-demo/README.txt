Owyx demo pack overlay
This tiny archive is a friends-sprint fixture.
The launcher installs vanilla/loader first, then extracts this zip into the instance game/ folder.
